# Использование Docker swarm и секретов

Создадим swarm cluster из 3 нод
